package com.AbstractDAOActivity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbstractDaoActivityApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbstractDaoActivityApplication.class, args);
	}

}
