package com.heejinhong.AbstractDAOActivity;

public final class Constants {
    public static final String MYSQL_CJ_JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    public static final String JDBC_MYSQL_LOCALHOST_MYDB = "jdbc:mysql://localhost:3306/mydb";

    public static final String MARIADB_CJ_JDBC_DRIVER = "com.mariadb.jdbc.Driver";
    public static final String JDBC_MARIADB_LOCALHOST_MYDB = "jdbc:mariadb://localhost:3306/mydb";

    public static final String USERNAME = "root";
    public static final String PASSWORD = "Password1";
}
