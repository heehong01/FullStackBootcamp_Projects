## School Management Service

Created By: Joanna Hong

###Scope:
    The scope of the School Management Service is to 

###Requirements:
    What were the requirements

###Student and Course Tables 
    - are created/initialized
    - populated

###Test Code
    - do i have test codes or not
    - Did the test code succeed or not



  
